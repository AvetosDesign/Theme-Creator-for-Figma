#!/usr/bin/env node

// src/cliArgs.ts
var DEFAULT_ASSET_BASE_URL = "/wp-content/uploads/wp-figma-gen-assets";
var USAGE = `Usage:
  wp-figma-gen --bundle <path-to-design-bundle.zip> --mode theme|patterns --out <output-dir>

Options:
  --bundle, -b          Path to a Design Bundle zip (design-bundle.json + /assets), per
                         ClaudeFiles/03-design-bundle-schema-draft.md
  --mode, -m            "theme"    -> generate a WordPress block theme scaffold (Phase 3)
                         "patterns" -> generate WordPress pattern-export JSON files (Phase 4)
  --out, -o             Output directory (created if it doesn't exist)
  --theme-slug, -t      Namespace prefix used for generated pattern slugs (patterns/*.php,
                         e.g. "<slug>/landing-page") \u2014 purely internal/cosmetic, does not
                         need to match the theme's actual installed folder name (D31).
                         Defaults to a slugified form of the Figma file name.
  --theme-name          Theme mode only. Overrides the "Theme Name:" header written into
                         style.css \u2014 the name WordPress actually displays in Appearance ->
                         Themes. Defaults to the bundle's own Figma file name
                         (bundle.meta.figmaFileName) when omitted.
  --asset-base-url, -u  Patterns mode only. Base URL images are referenced from, since
                         imported pattern JSON has no PHP execution to resolve one live
                         (D31 doesn't apply \u2014 see 02-decisions-log.md's Phase 4 entry).
                         Defaults to "${DEFAULT_ASSET_BASE_URL}"; upload the generated
                         /assets folder there, or pass the real destination URL.
  --no-fonts            Theme mode only. Skip downloading/self-hosting Google Fonts (D38) \u2014
                         text falls back to a generic CSS font-family (D37) instead. Useful
                         for offline machines or CI runs with restricted network access.
                         Font downloading is on by default.
  --help, -h            Show this message
  --version, -v         Print the installed version and exit (0). Checked before any other
                         argument is parsed \u2014 see index.ts's main(). Used by
                         Theme Creator for Figma's TCF_CLI_Runner to detect whether a
                         system-installed copy is new enough to prefer over its own bundled
                         one (D80 in 02-decisions-log.md).
`;
var CliUsageError = class extends Error {
};
var parseCliArgs = (argv) => {
  const flags = /* @__PURE__ */ new Map();
  let showHelp = false;
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    switch (arg) {
      case "--help":
      case "-h":
        showHelp = true;
        break;
      case "--bundle":
      case "-b":
        flags.set("bundle", argv[++i]);
        break;
      case "--mode":
      case "-m":
        flags.set("mode", argv[++i]);
        break;
      case "--out":
      case "-o":
        flags.set("out", argv[++i]);
        break;
      case "--theme-slug":
      case "-t":
        flags.set("themeSlug", argv[++i]);
        break;
      case "--theme-name":
        flags.set("themeName", argv[++i]);
        break;
      case "--asset-base-url":
      case "-u":
        flags.set("assetBaseUrl", argv[++i]);
        break;
      case "--no-fonts":
        flags.set("noFonts", "true");
        break;
      default:
        throw new CliUsageError(`Unrecognized argument: ${arg}

${USAGE}`);
    }
  }
  if (showHelp) {
    throw new CliUsageError(USAGE);
  }
  const bundlePath = flags.get("bundle");
  const mode = flags.get("mode");
  const outDir = flags.get("out");
  if (!bundlePath) throw new CliUsageError(`Missing required --bundle <path>

${USAGE}`);
  if (!outDir) throw new CliUsageError(`Missing required --out <dir>

${USAGE}`);
  if (mode !== "theme" && mode !== "patterns") {
    throw new CliUsageError(`--mode must be "theme" or "patterns" (got: ${mode ?? "<none>"})

${USAGE}`);
  }
  return {
    bundlePath,
    mode,
    outDir,
    themeSlug: flags.get("themeSlug"),
    themeName: flags.get("themeName"),
    assetBaseUrl: flags.get("assetBaseUrl"),
    downloadFonts: flags.get("noFonts") !== "true"
  };
};

// src/loadBundle.ts
import { readFileSync } from "fs";
import { createHash } from "crypto";

// ../../node_modules/.pnpm/fflate@0.8.3/node_modules/fflate/esm/index.mjs
import { createRequire } from "module";
var require2 = createRequire("/");
var _a;
var Worker;
var isMarkedAsUntransferable;
try {
  _a = require2("worker_threads"), Worker = _a.Worker, isMarkedAsUntransferable = _a.isMarkedAsUntransferable;
} catch (e) {
}
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]);
var fdeb = new u8([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]);
var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
var freb = function(eb, start) {
  var b = new u16(31);
  for (var i = 0; i < 31; ++i) {
    b[i] = start += 1 << eb[i - 1];
  }
  var r = new i32(b[30]);
  for (var i = 1; i < 30; ++i) {
    for (var j = b[i]; j < b[i + 1]; ++j) {
      r[j] = j - b[i] << 5 | i;
    }
  }
  return { b, r };
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (i = 0; i < 32768; ++i) {
  x = (i & 43690) >> 1 | (i & 21845) << 1;
  x = (x & 52428) >> 2 | (x & 13107) << 2;
  x = (x & 61680) >> 4 | (x & 3855) << 4;
  rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var x;
var i;
var hMap = (function(cd, mb, r) {
  var s = cd.length;
  var i = 0;
  var l = new u16(mb);
  for (; i < s; ++i) {
    if (cd[i])
      ++l[cd[i] - 1];
  }
  var le = new u16(mb);
  for (i = 1; i < mb; ++i) {
    le[i] = le[i - 1] + l[i - 1] << 1;
  }
  var co;
  if (r) {
    co = new u16(1 << mb);
    var rvb = 15 - mb;
    for (i = 0; i < s; ++i) {
      if (cd[i]) {
        var sv = i << 4 | cd[i];
        var r_1 = mb - cd[i];
        var v = le[cd[i] - 1]++ << r_1;
        for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
          co[rev[v] >> rvb] = sv;
        }
      }
    }
  } else {
    co = new u16(s);
    for (i = 0; i < s; ++i) {
      if (cd[i]) {
        co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
      }
    }
  }
  return co;
});
var flt = new u8(288);
for (i = 0; i < 144; ++i)
  flt[i] = 8;
var i;
for (i = 144; i < 256; ++i)
  flt[i] = 9;
var i;
for (i = 256; i < 280; ++i)
  flt[i] = 7;
var i;
for (i = 280; i < 288; ++i)
  flt[i] = 8;
var i;
var fdt = new u8(32);
for (i = 0; i < 32; ++i)
  fdt[i] = 5;
var i;
var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
var max = function(a) {
  var m = a[0];
  for (var i = 1; i < a.length; ++i) {
    if (a[i] > m)
      m = a[i];
  }
  return m;
};
var bits = function(d, p, m) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
  var o = p / 8 | 0;
  return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
  return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
  if (s == null || s < 0)
    s = 0;
  if (e == null || e > v.length)
    e = v.length;
  return new u8(v.subarray(s, e));
};
var ec = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
];
var err = function(ind, msg, nt) {
  var e = new Error(msg || ec[ind]);
  e.code = ind;
  if (Error.captureStackTrace)
    Error.captureStackTrace(e, err);
  if (!nt)
    throw e;
  return e;
};
var inflt = function(dat, st, buf, dict) {
  var sl = dat.length, dl = dict ? dict.length : 0;
  if (!sl || st.f && !st.l)
    return buf || new u8(0);
  var noBuf = !buf;
  var resize = noBuf || st.i != 2;
  var noSt = st.i;
  if (noBuf)
    buf = new u8(sl * 3);
  var cbuf = function(l2) {
    var bl = buf.length;
    if (l2 > bl) {
      var nbuf = new u8(Math.max(bl * 2, l2));
      nbuf.set(buf);
      buf = nbuf;
    }
  };
  var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
  var tbts = sl * 8;
  do {
    if (!lm) {
      final = bits(dat, pos, 1);
      var type = bits(dat, pos + 1, 3);
      pos += 3;
      if (!type) {
        var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
        if (t > sl) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + l);
        buf.set(dat.subarray(s, t), bt);
        st.b = bt += l, st.p = pos = t * 8, st.f = final;
        continue;
      } else if (type == 1)
        lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
      else if (type == 2) {
        var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
        var tl = hLit + bits(dat, pos + 5, 31) + 1;
        pos += 14;
        var ldt = new u8(tl);
        var clt = new u8(19);
        for (var i = 0; i < hcLen; ++i) {
          clt[clim[i]] = bits(dat, pos + i * 3, 7);
        }
        pos += hcLen * 3;
        var clb = max(clt), clbmsk = (1 << clb) - 1;
        var clm = hMap(clt, clb, 1);
        for (var i = 0; i < tl; ) {
          var r = clm[bits(dat, pos, clbmsk)];
          pos += r & 15;
          var s = r >> 4;
          if (s < 16) {
            ldt[i++] = s;
          } else {
            var c = 0, n = 0;
            if (s == 16)
              n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
            else if (s == 17)
              n = 3 + bits(dat, pos, 7), pos += 3;
            else if (s == 18)
              n = 11 + bits(dat, pos, 127), pos += 7;
            while (n--)
              ldt[i++] = c;
          }
        }
        var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
        lbt = max(lt);
        dbt = max(dt);
        lm = hMap(lt, lbt, 1);
        dm = hMap(dt, dbt, 1);
      } else
        err(1);
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
    }
    if (resize)
      cbuf(bt + 131072);
    var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
    var lpos = pos;
    for (; ; lpos = pos) {
      var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
      pos += c & 15;
      if (pos > tbts) {
        if (noSt)
          err(0);
        break;
      }
      if (!c)
        err(2);
      if (sym < 256)
        buf[bt++] = sym;
      else if (sym == 256) {
        lpos = pos, lm = null;
        break;
      } else {
        var add = sym - 254;
        if (sym > 264) {
          var i = sym - 257, b = fleb[i];
          add = bits(dat, pos, (1 << b) - 1) + fl[i];
          pos += b;
        }
        var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
        if (!d)
          err(3);
        pos += d & 15;
        var dt = fd[dsym];
        if (dsym > 3) {
          var b = fdeb[dsym];
          dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
        }
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (resize)
          cbuf(bt + 131072);
        var end = bt + add;
        if (bt < dt) {
          var shift = dl - dt, dend = Math.min(dt, end);
          if (shift + bt < 0)
            err(3);
          for (; bt < dend; ++bt)
            buf[bt] = dict[shift + bt];
        }
        for (; bt < end; ++bt)
          buf[bt] = buf[bt - dt];
      }
    }
    st.l = lm, st.p = lpos, st.b = bt, st.f = final;
    if (lm)
      final = 1, st.m = lbt, st.d = dm, st.n = dbt;
  } while (!final);
  return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var et = /* @__PURE__ */ new u8(0);
var b2 = function(d, b) {
  return d[b] | d[b + 1] << 8;
};
var b4 = function(d, b) {
  return (d[b] | d[b + 1] << 8 | d[b + 2] << 16 | d[b + 3] << 24) >>> 0;
};
var b8 = function(d, b) {
  return b4(d, b) + b4(d, b + 4) * 4294967296;
};
function inflateSync(data, opts) {
  return inflt(data, { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
var tds = 0;
try {
  td.decode(et, { stream: true });
  tds = 1;
} catch (e) {
}
var dutf8 = function(d) {
  for (var r = "", i = 0; ; ) {
    var c = d[i++];
    var eb = (c > 127) + (c > 223) + (c > 239);
    if (i + eb > d.length)
      return { s: r, r: slc(d, i - 1) };
    if (!eb)
      r += String.fromCharCode(c);
    else if (eb == 3) {
      c = ((c & 15) << 18 | (d[i++] & 63) << 12 | (d[i++] & 63) << 6 | d[i++] & 63) - 65536, r += String.fromCharCode(55296 | c >> 10, 56320 | c & 1023);
    } else if (eb & 1)
      r += String.fromCharCode((c & 31) << 6 | d[i++] & 63);
    else
      r += String.fromCharCode((c & 15) << 12 | (d[i++] & 63) << 6 | d[i++] & 63);
  }
};
function strFromU8(dat, latin1) {
  if (latin1) {
    var r = "";
    for (var i = 0; i < dat.length; i += 16384)
      r += String.fromCharCode.apply(null, dat.subarray(i, i + 16384));
    return r;
  } else if (td) {
    return td.decode(dat);
  } else {
    var _a2 = dutf8(dat), s = _a2.s, r = _a2.r;
    if (r.length)
      err(8);
    return s;
  }
}
var slzh = function(d, b) {
  return b + 30 + b2(d, b + 26) + b2(d, b + 28);
};
var zh = function(d, b, z) {
  var fnl = b2(d, b + 28), efl = b2(d, b + 30), fn = strFromU8(d.subarray(b + 46, b + 46 + fnl), !(b2(d, b + 8) & 2048)), es = b + 46 + fnl;
  var _a2 = z64hs(d, es, efl, z, b4(d, b + 20), b4(d, b + 24), b4(d, b + 42)), sc = _a2[0], su = _a2[1], off = _a2[2];
  return [b2(d, b + 10), sc, su, fn, es + efl + b2(d, b + 32), off];
};
var z64hs = function(d, b, l, z, sc, su, off) {
  var nsc = sc == 4294967295, nsu = su == 4294967295, noff = off == 4294967295, e = b + l;
  var nf = nsc + nsu + noff;
  if (z && nf) {
    for (; b + 4 < e; b += 4 + b2(d, b + 2)) {
      if (b2(d, b) == 1) {
        return [
          nsc ? b8(d, b + 4 + 8 * nsu) : sc,
          nsu ? b8(d, b + 4) : su,
          noff ? b8(d, b + 4 + 8 * (nsu + nsc)) : off,
          1
        ];
      }
    }
    if (z < 2)
      err(13);
  }
  return [sc, su, off, 0];
};
function unzipSync(data, opts) {
  var files = {};
  var e = data.length - 22;
  for (; b4(data, e) != 101010256; --e) {
    if (!e || data.length - e > 65558)
      err(13);
  }
  ;
  var c = b2(data, e + 8);
  if (!c)
    return {};
  var o = b4(data, e + 16);
  var z = b4(data, e - 20) == 117853008;
  if (z) {
    var ze = b4(data, e - 12);
    z = b4(data, ze) == 101075792;
    if (z) {
      c = b4(data, ze + 32);
      o = b4(data, ze + 48);
    }
  }
  var fltr = opts && opts.filter;
  for (var i = 0; i < c; ++i) {
    var _a2 = zh(data, o, z), c_2 = _a2[0], sc = _a2[1], su = _a2[2], fn = _a2[3], no = _a2[4], off = _a2[5], b = slzh(data, off);
    o = no;
    if (!fltr || fltr({
      name: fn,
      size: sc,
      originalSize: su,
      compression: c_2
    })) {
      if (!c_2)
        files[fn] = slc(data, b, b + sc);
      else if (c_2 == 8)
        files[fn] = inflateSync(data.subarray(b, b + sc), { out: new u8(su) });
      else
        err(14, "unknown compression type " + c_2);
    }
  }
  return files;
}

// src/loadBundle.ts
var DesignBundleValidationError = class extends Error {
};
var dedupeAssetsByContent = (bundle, assets) => {
  const canonicalFileNameByHash = /* @__PURE__ */ new Map();
  const renameToCanonical = /* @__PURE__ */ new Map();
  for (const [fileName, bytes] of Object.entries(assets)) {
    const hash = createHash("sha256").update(bytes).digest("hex");
    const canonical = canonicalFileNameByHash.get(hash);
    if (canonical) {
      renameToCanonical.set(fileName, canonical);
    } else {
      canonicalFileNameByHash.set(hash, fileName);
    }
  }
  if (renameToCanonical.size === 0) return;
  for (const asset of bundle.assets ?? []) {
    const canonical = renameToCanonical.get(asset.fileName);
    if (canonical) {
      asset.fileName = canonical;
    }
  }
  for (const oldFileName of renameToCanonical.keys()) {
    delete assets[oldFileName];
  }
};
var loadDesignBundle = (bundlePath) => {
  let zipBytes;
  try {
    zipBytes = readFileSync(bundlePath);
  } catch (error) {
    throw new DesignBundleValidationError(
      `Could not read bundle at "${bundlePath}": ${error.message}`
    );
  }
  let files;
  try {
    files = unzipSync(zipBytes);
  } catch (error) {
    throw new DesignBundleValidationError(
      `"${bundlePath}" is not a valid zip file: ${error.message}`
    );
  }
  const manifestBytes = files["design-bundle.json"];
  if (!manifestBytes) {
    throw new DesignBundleValidationError(
      `"${bundlePath}" has no design-bundle.json at its root \u2014 is this a Design Bundle zip?`
    );
  }
  let bundle;
  try {
    bundle = JSON.parse(Buffer.from(manifestBytes).toString("utf-8"));
  } catch (error) {
    throw new DesignBundleValidationError(
      `design-bundle.json in "${bundlePath}" is not valid JSON: ${error.message}`
    );
  }
  if (bundle.schemaVersion !== 1) {
    throw new DesignBundleValidationError(
      `Unsupported bundle schemaVersion "${bundle.schemaVersion}" \u2014 this build of wp-figma-gen only understands schemaVersion 1.`
    );
  }
  if (!Array.isArray(bundle.designs) || bundle.designs.length === 0) {
    throw new DesignBundleValidationError(
      `Bundle has no designs[] entries \u2014 nothing to generate.`
    );
  }
  const assets = {};
  const missing = [];
  for (const asset of bundle.assets ?? []) {
    const bytes = files[asset.fileName];
    if (!bytes) {
      missing.push(asset.fileName);
      continue;
    }
    assets[asset.fileName] = bytes;
  }
  if (missing.length > 0) {
    throw new DesignBundleValidationError(
      `Bundle's assets[] manifest references file(s) not present in the zip: ${missing.join(", ")}. Re-export the bundle from Figma (see D19 for a known past cause of this).`
    );
  }
  dedupeAssetsByContent(bundle, assets);
  return { bundle, assets };
};

// src/theme/generateThemeFiles.ts
import { existsSync as existsSync2, mkdirSync, readFileSync as readFileSync3, writeFileSync } from "fs";
import { join as join2 } from "path";

// src/blocks/styleHelpers.ts
var buildInlineStyle = (declarations) => declarations.filter((entry) => Boolean(entry[1])).map(([prop, value]) => `${prop}: ${value}`).join("; ");
var joinStyles = (...fragments) => fragments.filter((f) => Boolean(f)).join("; ");
var sizeToCss = (value, axis) => {
  if (value === "hug") return void 0;
  if (value === "fill") return axis === "width" ? "width: 100%; flex: 1 1 auto" : "height: 100%; flex: 1 1 auto";
  return `${axis}: ${value}px`;
};
var primaryAxisAlignToCss = (align) => {
  switch (align) {
    case "MIN":
      return "flex-start";
    case "CENTER":
      return "center";
    case "MAX":
      return "flex-end";
    case "SPACE_BETWEEN":
      return "space-between";
  }
};
var counterAxisAlignToCss = (align) => {
  switch (align) {
    case "MIN":
      return "flex-start";
    case "CENTER":
      return "center";
    case "MAX":
      return "flex-end";
    case "BASELINE":
      return "baseline";
  }
};
var layoutToDeclarations = (layout, paintOrder) => {
  const declarations = [];
  declarations.push(["margin", "0"]);
  if (layout.mode !== "NONE") {
    declarations.push(["display", "flex"]);
    declarations.push(["flex-direction", layout.mode === "HORIZONTAL" ? "row" : "column"]);
    if (layout.wrap) declarations.push(["flex-wrap", "wrap"]);
    declarations.push(["justify-content", primaryAxisAlignToCss(layout.primaryAxisAlign)]);
    declarations.push(["align-items", counterAxisAlignToCss(layout.counterAxisAlign)]);
    if (layout.rowGap !== void 0 && layout.rowGap !== layout.gap) {
      declarations.push(["gap", `${layout.rowGap}px ${layout.gap}px`]);
    } else if (layout.gap) {
      declarations.push(["gap", `${layout.gap}px`]);
    }
  }
  const { top, right, bottom, left } = layout.padding;
  if (top || right || bottom || left) {
    declarations.push(["padding", `${top}px ${right}px ${bottom}px ${left}px`]);
  }
  if (layout.position) {
    declarations.push(["position", "absolute !important"]);
    declarations.push(["left", `${layout.position.x}px`]);
    declarations.push(["top", `${layout.position.y}px`]);
    if (paintOrder !== void 0) declarations.push(["z-index", String(paintOrder)]);
  }
  const width = sizeToCss(layout.sizing.width, "width");
  const height = sizeToCss(layout.sizing.height, "height");
  return joinStyles(buildInlineStyle(declarations), width, height);
};
var withAlpha = (hex, opacity) => {
  if (opacity === void 0) return hex;
  const alphaHex = Math.round(Math.max(0, Math.min(1, opacity)) * 255).toString(16).padStart(2, "0").toUpperCase();
  return `${hex}${alphaHex}`;
};
var gradientToCss = (gradient) => {
  const stopsAt = (positionMultiplier, unit) => gradient.stops.map((stop) => `${stop.hex} ${(stop.position * positionMultiplier).toFixed(0)}${unit}`).join(", ");
  if (gradient.kind === "LINEAR") {
    const [start, end] = gradient.handles;
    const dx2 = end.x - start.x;
    const dy2 = end.y - start.y;
    let angle2 = Math.atan2(dy2, dx2) * (180 / Math.PI);
    angle2 = (angle2 + 360) % 360;
    const cssAngle = (angle2 + 90) % 360;
    return `linear-gradient(${cssAngle.toFixed(0)}deg, ${stopsAt(100, "%")})`;
  }
  if (gradient.kind === "RADIAL") {
    const [center2, h1, h2] = gradient.handles;
    const cx2 = center2.x * 100;
    const cy2 = center2.y * 100;
    const rx = Math.sqrt((h1.x - center2.x) ** 2 + (h1.y - center2.y) ** 2) * 100;
    const ry = Math.sqrt((h2.x - center2.x) ** 2 + (h2.y - center2.y) ** 2) * 100;
    return `radial-gradient(ellipse ${rx.toFixed(2)}% ${ry.toFixed(2)}% at ${cx2.toFixed(2)}% ${cy2.toFixed(2)}%, ${stopsAt(100, "%")})`;
  }
  const [center, , startDirection] = gradient.handles;
  const cx = center.x * 100;
  const cy = center.y * 100;
  const dx = startDirection.x - center.x;
  const dy = startDirection.y - center.y;
  let angle = Math.atan2(dy, dx) * (180 / Math.PI);
  angle = (angle + 360) % 360;
  return `conic-gradient(from ${angle.toFixed(0)}deg at ${cx.toFixed(2)}% ${cy.toFixed(2)}%, ${stopsAt(360, "deg")})`;
};
var effectsToDeclarations = (effects) => {
  const shadows = effects.filter((e) => (e.type === "DROP_SHADOW" || e.type === "INNER_SHADOW") && e.hex).map((e) => {
    const inset = e.type === "INNER_SHADOW" ? "inset " : "";
    const spread = e.spread ? ` ${e.spread}px` : "";
    return `${inset}${e.x ?? 0}px ${e.y ?? 0}px ${e.blur ?? 0}px${spread} ${e.hex}`;
  });
  const layerBlur = effects.find((e) => e.type === "LAYER_BLUR" && typeof e.blur === "number");
  const backgroundBlur = effects.find((e) => e.type === "BACKGROUND_BLUR" && typeof e.blur === "number");
  const declarations = [];
  if (shadows.length > 0) declarations.push(["box-shadow", shadows.join(", ")]);
  if (layerBlur) declarations.push(["filter", `blur(${layerBlur.blur}px)`]);
  if (backgroundBlur) {
    declarations.push(["-webkit-backdrop-filter", `blur(${backgroundBlur.blur}px)`]);
    declarations.push(["backdrop-filter", `blur(${backgroundBlur.blur}px)`]);
  }
  return declarations;
};
var nodeStyleToDeclarations = (style, skipBackground) => {
  const declarations = [];
  const paintableFill = style.fills.find((f) => (f.type === "SOLID" || f.type === "GRADIENT") && f.hex);
  if (paintableFill?.hex && !skipBackground) {
    if (paintableFill.gradient) {
      declarations.push(["background-image", gradientToCss(paintableFill.gradient)]);
    } else {
      declarations.push(["background-color", withAlpha(paintableFill.hex, paintableFill.opacity)]);
    }
  }
  const stroke = style.strokes[0];
  if (stroke?.hex) declarations.push(["border", `${stroke.weight}px solid ${stroke.hex}`]);
  if (style.cornerRadius) declarations.push(["border-radius", `${style.cornerRadius}px`]);
  if (style.opacity !== void 0) declarations.push(["opacity", String(style.opacity)]);
  if (style.blendMode !== void 0) declarations.push(["mix-blend-mode", style.blendMode]);
  declarations.push(...effectsToDeclarations(style.effects));
  return buildInlineStyle(declarations);
};
var MONOSPACE_FAMILY_HINTS = ["mono", "courier", "consolas", "code"];
var SERIF_FAMILY_HINTS = ["serif", "georgia", "times", "garamond", "playfair", "merriweather", "baskerville"];
var fontFamilyDeclaration = (fontFamily) => {
  const lower = fontFamily.toLowerCase();
  const generic = MONOSPACE_FAMILY_HINTS.some((hint) => lower.includes(hint)) ? "monospace" : SERIF_FAMILY_HINTS.some((hint) => lower.includes(hint)) && !lower.includes("sans") ? "serif" : "sans-serif";
  return `"${fontFamily}", ${generic}`;
};
var escapeHtml = (text) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");

// src/blocks/headingHeuristic.ts
var HEADING_STYLE_NAME_PATTERN = /^heading\/h([1-6])$/i;
var levelFromNamedStyle = (segment, textStyles) => {
  if (!segment?.textStyleId) return void 0;
  const resolved = textStyles[segment.textStyleId];
  if (!resolved) return void 0;
  const match = HEADING_STYLE_NAME_PATTERN.exec(resolved.name.trim());
  return match ? Number(match[1]) : void 0;
};
var levelFromSizeHeuristic = (segment) => {
  if (!segment) return void 0;
  const fontSize = segment.fontSize;
  const fontWeight = parseInt(segment.fontWeight, 10) || 0;
  if (fontSize >= 40) return 1;
  if (fontSize >= 32) return 2;
  if (fontSize >= 24) return 3;
  if (fontSize >= 20) return 4;
  if (fontSize >= 18 && fontWeight >= 600) return 5;
  return void 0;
};
var headingLevelFor = (segments, textStyles = {}) => {
  const first = segments[0];
  return levelFromNamedStyle(first, textStyles) ?? levelFromSizeHeuristic(first);
};

// src/blocks/nodeClass.ts
var nodeClassFor = (nodeId) => `wpfg-${nodeId.replace(/[^a-zA-Z0-9]+/g, "-")}`;

// src/blocks/stylesheet.ts
var createStylesheet = () => /* @__PURE__ */ new Map();
var addRule = (stylesheet, className, declarations) => {
  if (declarations) stylesheet.set(className, declarations);
};
var renderStylesheet = (stylesheet) => Array.from(stylesheet, ([className, declarations]) => `.${className} { ${declarations}; }`).join("\n");

// src/theme/slugify.ts
var toSlug = (value) => (value || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "untitled";
var insertWordBoundaries = (value) => value.replace(/([a-zA-Z])([0-9])/g, "$1-$2").replace(/([0-9])([a-zA-Z])/g, "$1-$2");
var toPresetSlug = (value) => insertWordBoundaries(toSlug(value));
var assignUniqueSlugs = (names, slugFn = toSlug) => {
  const seen = /* @__PURE__ */ new Map();
  return names.map((name) => {
    const base = slugFn(name);
    const count = seen.get(base) ?? 0;
    seen.set(base, count + 1);
    return count === 0 ? base : `${base}-${count + 1}`;
  });
};

// src/blocks/formMapping.ts
var NAMESPACED = /^([A-Za-z]+)\s*\/\s*(.+)$/;
var stripDedupSuffix = (name) => name.replace(/_\d+$/, "");
var parseNamespaced = (name) => {
  const match = NAMESPACED.exec(name.trim());
  if (!match) return void 0;
  return { category: match[1], rest: match[2].trim() };
};
var matchesCategory = (name, category) => {
  const parsed = parseNamespaced(name);
  return parsed && parsed.category.toLowerCase() === category.toLowerCase() ? parsed : void 0;
};
var matchesBareCategory = (name, category) => stripDedupSuffix(name.trim()).toLowerCase() === category.toLowerCase();
var FIELD_TYPE_KEYWORDS = [
  [/email/i, "email"],
  [/phone/i, "tel"],
  [/url|website/i, "url"],
  [/date/i, "date"]
];
var isTextareaField = (fieldName) => /message/i.test(fieldName);
var inputTypeFor = (fieldName) => {
  for (const [pattern, type] of FIELD_TYPE_KEYWORDS) {
    if (pattern.test(fieldName)) return type;
  }
  return "text";
};
var BUTTON_TYPE_KEYWORDS = [
  [/submit/i, "submit"],
  [/reset/i, "reset"]
];
var buttonTypeFor = (buttonType) => {
  for (const [pattern, type] of BUTTON_TYPE_KEYWORDS) {
    if (pattern.test(buttonType)) return type;
  }
  return "button";
};
var slugifyFieldName = (fieldName) => toSlug(fieldName.replace(/([a-z0-9])([A-Z])/g, "$1-$2"));
var detectField = (node) => {
  const parsed = matchesCategory(node.uniqueName, "Input");
  if (!parsed || node.type !== "FRAME") return void 0;
  const label = node.children.find((c) => matchesCategory(c.uniqueName, "Label"));
  const field = node.children.find((c) => matchesBareCategory(c.uniqueName, "Field"));
  if (!label || !field || label.type !== "TEXT" || field.type !== "FRAME") return void 0;
  const valueChild = field.children.find(
    (c) => matchesBareCategory(c.uniqueName, "Hint") || matchesBareCategory(c.uniqueName, "Value")
  );
  if (!valueChild || valueChild.type !== "TEXT") return void 0;
  return {
    input: node,
    fieldName: parsed.rest,
    label,
    field,
    valueNode: valueChild,
    isValue: matchesBareCategory(valueChild.uniqueName, "Value")
  };
};
var detectButton = (node) => {
  const parsed = matchesCategory(node.uniqueName, "Button");
  if (!parsed || node.type !== "FRAME") return void 0;
  const label = node.children.find((c) => matchesCategory(c.uniqueName, "Label"));
  if (!label || label.type !== "TEXT") return void 0;
  return { button: node, buttonType: parsed.rest, label };
};
var detectForm = (node, warnIfNamedButInvalid) => {
  if (node.type !== "FRAME" || !matchesCategory(node.uniqueName, "Form")) return void 0;
  const fields = [];
  const buttons = [];
  for (const child of node.children) {
    const field = detectField(child);
    if (field) {
      fields.push(field);
      continue;
    }
    const button = detectButton(child);
    if (button) {
      buttons.push(button);
      continue;
    }
    warnIfNamedButInvalid?.(
      `"${node.uniqueName}" is named like a Form but child "${child.uniqueName}" doesn't match the required Input/Button shape (see 06-block-mapping.md) \u2014 rendering as a plain group instead.`
    );
    return void 0;
  }
  if (fields.length === 0 || buttons.length === 0) {
    warnIfNamedButInvalid?.(
      `"${node.uniqueName}" is named like a Form but has no valid Input and/or Button children \u2014 rendering as a plain group instead.`
    );
    return void 0;
  }
  return { form: node, fields, buttons };
};
var boxClass = (node, ctx, extra) => {
  const declarations = joinStyles(
    "box-sizing: border-box",
    layoutToDeclarations(node.layout, node.paintOrder),
    nodeStyleToDeclarations(node.style, false),
    extra
  );
  if (!declarations) return void 0;
  const cls = nodeClassFor(node.id);
  addRule(ctx.stylesheet, cls, declarations);
  return cls;
};
var captionDeclarations = (node) => {
  const first = node.text?.segments?.[0];
  if (!first) return void 0;
  return joinStyles(
    `font-family: ${fontFamilyDeclaration(first.fontFamily)}`,
    `font-size: ${first.fontSize}px`,
    `font-weight: ${first.fontWeight}`,
    first.lineHeight ? `line-height: ${first.lineHeight}` : void 0,
    first.fillHex ? `color: ${withAlpha(first.fillHex, first.fillOpacity)}` : void 0
  );
};
var captionText = (node) => escapeHtml((node.text?.segments ?? []).map((s) => s.characters).join(""));
var attr = (name, value) => value === void 0 ? "" : ` ${name}="${escapeHtml(value)}"`;
var renderField = (formSlug, detected, ctx) => {
  const fieldSlug = slugifyFieldName(detected.fieldName);
  const id = `${formSlug}-${fieldSlug}`;
  const labelText2 = captionText(detected.label);
  const valueText = captionText(detected.valueNode);
  const wrapperClass = boxClass(detected.input, ctx);
  const fieldClass = boxClass(detected.field, ctx, captionDeclarations(detected.valueNode));
  const labelClass = (() => {
    const decl = captionDeclarations(detected.label);
    if (!decl) return void 0;
    const cls = nodeClassFor(detected.label.id);
    addRule(ctx.stylesheet, cls, decl);
    return cls;
  })();
  const valueAttr = detected.isValue ? attr("value", valueText) : attr("placeholder", valueText);
  const controlHtml = isTextareaField(detected.fieldName) ? `<textarea id="${id}" name="${fieldSlug}" rows="4"${attr("class", fieldClass)}${valueAttr}>${detected.isValue ? valueText : ""}</textarea>` : `<input type="${inputTypeFor(detected.fieldName)}" id="${id}" name="${fieldSlug}"${attr("class", fieldClass)}${valueAttr}/>`;
  return `<div${attr("class", wrapperClass)}><label for="${id}"${attr("class", labelClass)}>${labelText2}</label>` + controlHtml + `</div>`;
};
var renderButton = (detected, ctx) => {
  const labelText2 = captionText(detected.label);
  const buttonClass = boxClass(detected.button, ctx, captionDeclarations(detected.label));
  return `<button type="${buttonTypeFor(detected.buttonType)}"${attr("class", buttonClass)}>${labelText2}</button>`;
};
var renderForm = (detected, ctx) => {
  const formSlug = toSlug(detected.form.uniqueName.replace(/^Form\s*\/\s*/i, ""));
  const formClass = boxClass(detected.form, ctx);
  const fieldsHtml = detected.fields.map((f) => renderField(formSlug, f, ctx)).join("");
  const buttonsHtml = detected.buttons.map((b) => renderButton(b, ctx)).join("");
  return {
    blockName: "core/html",
    attrs: {},
    tagName: "div",
    innerHtml: `<form${attr("class", formClass)}>${fieldsHtml}${buttonsHtml}</form>`
  };
};

// src/blocks/linkMapping.ts
var NAMESPACED2 = /^([A-Za-z]+)\s*\/\s*(.+)$/;
var parseNamespaced2 = (name) => {
  const match = NAMESPACED2.exec(name.trim());
  if (!match) return void 0;
  return { category: match[1], rest: match[2].trim() };
};
var matchesCategory2 = (name, category) => {
  const parsed = parseNamespaced2(name);
  return parsed && parsed.category.toLowerCase() === category.toLowerCase() ? parsed : void 0;
};
var detectLink = (node, warnIfNamedButInvalid) => {
  const parsed = matchesCategory2(node.uniqueName, "Link");
  if (!parsed) return void 0;
  if (node.type === "TEXT") {
    return { linkNode: node, page: parsed.rest, label: node };
  }
  if (node.type !== "FRAME") {
    warnIfNamedButInvalid?.(
      `"${node.uniqueName}" is named like a Link but is a ${node.type} node, not TEXT or FRAME \u2014 rendering normally instead.`
    );
    return void 0;
  }
  const textChildren = node.children.filter((c) => c.type === "TEXT");
  const iconChildren = node.children.filter((c) => c.type === "IMAGE" || c.type === "VECTOR");
  const otherChildren = node.children.filter((c) => c.type !== "TEXT" && c.type !== "IMAGE" && c.type !== "VECTOR");
  if (textChildren.length !== 1 || iconChildren.length > 1 || otherChildren.length > 0) {
    warnIfNamedButInvalid?.(
      `"${node.uniqueName}" is named like a Link but doesn't match the required shape (exactly one text label, at most one icon \u2014 see 06-block-mapping.md) \u2014 rendering as a plain group instead.`
    );
    return void 0;
  }
  return { linkNode: node, page: parsed.rest, label: textChildren[0], icon: iconChildren[0] };
};
var labelText = (node) => escapeHtml((node.text?.segments ?? []).map((s) => s.characters).join(""));
var fontDeclarations = (node) => {
  const first = node.text?.segments?.[0];
  if (!first) return void 0;
  return joinStyles(
    `font-family: ${fontFamilyDeclaration(first.fontFamily)}`,
    `font-size: ${first.fontSize}px`,
    `font-weight: ${first.fontWeight}`,
    first.lineHeight ? `line-height: ${first.lineHeight}` : void 0,
    first.fillHex ? `color: ${withAlpha(first.fillHex, first.fillOpacity)}` : void 0
  );
};
var attr2 = (name, value) => value === void 0 ? "" : ` ${name}="${escapeHtml(value)}"`;
var classFor = (node, ctx, declarations) => {
  if (!declarations) return void 0;
  const cls = nodeClassFor(node.id);
  addRule(ctx.stylesheet, cls, declarations);
  return cls;
};
var resolveAssetSrc = (asset, ctx) => ctx.imageSrcMode?.kind === "url" ? `${ctx.imageSrcMode.baseUrl.replace(/\/$/, "")}/${asset.fileName.replace(/^assets\//, "")}` : `<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/${asset.fileName.replace(/^assets\//, "")}`;
var renderLink = (detected, ctx) => {
  const isBareText = detected.linkNode.id === detected.label.id;
  const outerDeclarations = joinStyles(
    layoutToDeclarations(detected.linkNode.layout, detected.linkNode.paintOrder),
    nodeStyleToDeclarations(detected.linkNode.style, isBareText),
    isBareText ? fontDeclarations(detected.label) : void 0
  );
  const outerClass = classFor(detected.linkNode, ctx, outerDeclarations);
  const iconHtml = (() => {
    if (!detected.icon) return "";
    const asset = detected.icon.assetRef ? ctx.assetsById.get(detected.icon.assetRef) : void 0;
    if (!asset) return "";
    const iconClass = classFor(
      detected.icon,
      ctx,
      joinStyles(
        layoutToDeclarations(detected.icon.layout, detected.icon.paintOrder),
        detected.icon.style.opacity !== void 0 ? `opacity: ${detected.icon.style.opacity}` : void 0
      )
    );
    return `<img src="${resolveAssetSrc(asset, ctx)}" alt=""${attr2("class", iconClass)}/>`;
  })();
  const innerHtml = isBareText ? labelText(detected.label) : `<span${attr2("class", classFor(detected.label, ctx, fontDeclarations(detected.label)))}>${labelText(detected.label)}</span>${iconHtml}`;
  return {
    blockName: "core/html",
    attrs: {},
    tagName: "div",
    innerHtml: `<a href="#${escapeHtml(toSlug(detected.page))}"${attr2("class", outerClass)}${attr2("data-figma-link", detected.page)}>${innerHtml}</a>`
  };
};

// src/blocks/mapNode.ts
var warn = (ctx, nodeId, message) => {
  ctx.warnings.push({ nodeId, message });
};
var mapText = (node, ctx) => {
  const segments = node.text?.segments ?? [];
  if (segments.length === 0) {
    warn(ctx, node.id, "TEXT node has no text.segments \u2014 rendering an empty paragraph.");
  }
  if (segments.length > 1) {
    warn(
      ctx,
      node.id,
      `TEXT node has ${segments.length} runs \u2014 concatenated into plain text without per-run styling (v1 limitation, see 06-block-mapping.md).`
    );
  }
  const innerHtml = segments.map((s) => escapeHtml(s.characters)).join("");
  const first = segments[0];
  const level = headingLevelFor(segments, ctx.textStyles ?? {});
  const textColorSlug = first?.fillRef ? ctx.colorSlugByVariableRef?.get(first.fillRef) : void 0;
  const fontSizeSlug = first?.textStyleId ? ctx.fontSizeSlugByTextStyleId?.get(first.textStyleId) : void 0;
  const presetAttrs = {};
  if (textColorSlug) presetAttrs.textColor = textColorSlug;
  if (fontSizeSlug) presetAttrs.fontSize = fontSizeSlug;
  const presetClasses = [
    textColorSlug ? `has-${textColorSlug}-color has-text-color` : void 0,
    fontSizeSlug ? `has-${fontSizeSlug}-font-size` : void 0
  ].filter(Boolean).join(" ");
  const textLayout = typeof node.layout.sizing.height === "number" ? { ...node.layout, sizing: { ...node.layout.sizing, height: "hug" } } : node.layout;
  const customDeclarations = joinStyles(
    layoutToDeclarations(textLayout, node.paintOrder),
    first ? joinStyles(
      `font-family: ${fontFamilyDeclaration(first.fontFamily)}`,
      fontSizeSlug ? void 0 : `font-size: ${first.fontSize}px`,
      `font-weight: ${first.fontWeight}`,
      // D56 (corrected): `first.lineHeight` is a unitless *ratio*
      // (designBundleTree.ts's mapTextSegments deliberately computes
      // `lineHeightPx / fontSize`, e.g. `1.5`, not a raw px value) — a
      // bare number here is correct, idiomatic CSS (`line-height: 1.5`
      // means 1.5x font-size, and scales properly if font-size ever
      // changes, unlike a fixed px value would). D56's first attempt
      // wrongly assumed this was already in pixels and appended `px`,
      // which turned a real `1.5` into a near-zero `1.5px` — collapsing
      // every paragraph's lines into each other. Reverted that part.
      // What D56 got right and keeps: `commonLineHeight` (in
      // commonTextHeightSpacing.ts) returns a literal `0` for Figma's
      // "Auto" line-height (no real ratio to report) — emitting that
      // unconditionally as `line-height: 0` creates strongly negative
      // half-leading, visibly shifting the rendered glyph upward out
      // of its own box (dramatic on large headings, easy to miss on
      // small body text — the H1/H2 vs. H3 split Sean observed). Still
      // omitted entirely when 0, letting the browser's own
      // `line-height: normal` apply — the real semantic equivalent of
      // Figma's "Auto."
      first.lineHeight ? `line-height: ${first.lineHeight}` : void 0,
      textColorSlug || !first.fillHex ? void 0 : `color: ${withAlpha(first.fillHex, first.fillOpacity)}`
    ) : void 0,
    node.style.opacity !== void 0 ? `opacity: ${node.style.opacity}` : void 0,
    // D72: TEXT nodes build their own declarations here rather than
    // going through `nodeStyleToDeclarations` (containers only) — same
    // reason the opacity line just above is duplicated instead of shared.
    node.style.blendMode !== void 0 ? `mix-blend-mode: ${node.style.blendMode}` : void 0,
    // D55: Figma's textAlignHorizontal — Stage 1 only ever records
    // CENTER/RIGHT/JUSTIFIED (LEFT is the CSS default, so it's never
    // captured at all — see designBundleTree.ts). A previously-missing
    // capability project-wide, not a regression from D52/D53/D54: this
    // pipeline never emitted `text-align` for any TEXT node before this.
    node.text?.align ? `text-align: ${node.text.align.toLowerCase()}` : void 0
  );
  const nodeClass = nodeClassFor(node.id);
  addRule(ctx.stylesheet, nodeClass, customDeclarations);
  const customClass = customDeclarations ? nodeClass : void 0;
  const classNameAttr = customClass ? { className: customClass } : {};
  if (level !== void 0) {
    return {
      blockName: "core/heading",
      attrs: { level, ...presetAttrs, ...classNameAttr },
      tagName: `h${level}`,
      className: ["wp-block-heading", customClass, presetClasses].filter(Boolean).join(" ") || void 0,
      innerHtml
    };
  }
  return {
    blockName: "core/paragraph",
    attrs: { ...presetAttrs, ...classNameAttr },
    tagName: "p",
    // D53: every real core block gets a `wp-block-{name}` base class by
    // default (WordPress's own `get_block_default_classname()`) — the
    // heading branch above already includes its own (`wp-block-heading`),
    // but this branch never did. Without it, a generated `<p>` never
    // matches WP's own CSS reset for paragraph margins, so the browser's
    // raw user-agent default (`margin-block: 1em`) silently applies
    // instead — invisible in normal document flow (just extra
    // whitespace), but a real, visible overlap once a sibling is taken
    // out of flow via `position: absolute` (D52) and anchored to an exact
    // Figma-derived offset that doesn't account for the stray margin.
    className: ["wp-block-paragraph", customClass, presetClasses].filter(Boolean).join(" ") || void 0,
    innerHtml
  };
};
var resolveAssetSrc2 = (asset, ctx) => ctx.imageSrcMode?.kind === "url" ? `${ctx.imageSrcMode.baseUrl.replace(/\/$/, "")}/${asset.fileName.replace(/^assets\//, "")}` : `<?php echo esc_url( get_stylesheet_directory_uri() ); ?>/assets/${asset.fileName.replace(/^assets\//, "")}`;
var mapImageLike = (node, ctx) => {
  const asset = node.assetRef ? ctx.assetsById.get(node.assetRef) : void 0;
  if (!asset) {
    warn(ctx, node.id, `${node.type} node has no resolvable asset (assetRef: ${node.assetRef ?? "<none>"}) \u2014 rendering a placeholder image.`);
  }
  const layoutDeclarations = joinStyles(
    layoutToDeclarations(node.layout, node.paintOrder),
    node.style.opacity !== void 0 ? `opacity: ${node.style.opacity}` : void 0,
    // D72: same "this leaf builds its own declarations, doesn't go
    // through nodeStyleToDeclarations" reasoning as the opacity line
    // above.
    node.style.blendMode !== void 0 ? `mix-blend-mode: ${node.style.blendMode}` : void 0
  );
  const nodeClass = nodeClassFor(node.id);
  addRule(ctx.stylesheet, nodeClass, layoutDeclarations);
  const customClass = layoutDeclarations ? nodeClass : void 0;
  return {
    blockName: "core/image",
    // sizeSlug (and its "size-full" class below) only appears when an
    // asset actually resolved — claiming it unconditionally, regardless of
    // whether `sizeSlug` was set, was itself a real attrs/HTML mismatch.
    //
    // D42: `width`/`height` are deliberately NOT included here, even though
    // an asset's real dimensions are known. Gutenberg's actual core/image
    // save.js (verified directly against WordPress/gutenberg's source)
    // emits an inline `style="width:{n}px;height:{n}px"` on the <img>
    // itself whenever attrs.width/attrs.height are set — our rendered
    // markup never reproduced that inline style, which is exactly the
    // attrs/HTML mismatch D27 warns about (silent "Attempt Recovery" in
    // the editor). Sizing is already fully handled by our own `nodeClass`
    // CSS on the <figure> wrapper (D33's layoutToDeclarations), so these
    // attrs were redundant anyway — dropping them removes the mismatch
    // instead of chasing save()'s inline-style format. The plain HTML
    // width/height attributes below (extraAttrs) are unaffected; those
    // are just CLS hints on the <img> tag, not part of what save()
    // validates against stored attrs.
    attrs: {
      ...asset ? { sizeSlug: "full" } : {},
      ...customClass ? { className: customClass } : {}
    },
    tagName: "img",
    isVoid: true,
    wrapperTagName: "figure",
    wrapperClassName: [asset ? "wp-block-image size-full" : "wp-block-image", customClass].filter(Boolean).join(" "),
    extraAttrs: {
      // D31 (theme mode, supersedes D30's static-absolute-path attempt): a
      // relative or even a hardcoded site-root-absolute path can never
      // correctly know the real domain (or subdirectory install prefix) at
      // generation time. Real WordPress themes solve this by only ever
      // referencing theme-bundled assets from PHP-executed context — a
      // `patterns/*.php` file, where `get_stylesheet_directory_uri()`
      // resolves to the correct, live URL fresh on every request.
      //
      // Phase 4 (patterns mode, see MapNodeContext.imageSrcMode above): a
      // pattern imported via "Import from JSON" is stored post content, not
      // a PHP file — a `<?php ... ?>` tag would render as literal inert
      // text, not execute. There's no live-resolution mechanism available at
      // all in that context, so the caller supplies a generation-time-known
      // base URL instead (documented, loud-by-default, per D30's lesson
      // about guessed paths needing to be diagnosable rather than silently
      // wrong).
      // D42 follow-up: literal HTML `width=`/`height=` attributes on the
      // <img> were dropped entirely, not just the JSON attrs (the original
      // D42 fix only removed the latter). Gutenberg's real core/image
      // save() (verified directly against its current source) NEVER emits
      // HTML width/height attributes on the <img> — dimensions only ever
      // appear as an inline `style="width:...px;height:...px"`, and only
      // when attrs.width/height are set. Since D42 already dropped those
      // attrs (so no inline style is expected either), a bare <img
      // src=... alt=.../> with no width/height anywhere is what save()
      // actually reconstructs — the leftover raw HTML attributes here were
      // a second, independent mismatch from the same root cause, and
      // explain why *every* image (not just ones with a custom class)
      // showed "unexpected or invalid content" in the editor. Sizing is
      // still fully enforced by our own `nodeClass` CSS on the <figure>
      // wrapper (D33); losing the img-level width/height hint is a minor,
      // acceptable CLS trade-off against actually validating.
      src: asset ? resolveAssetSrc2(asset, ctx) : "",
      alt: ""
    }
  };
};
var isEffectMapped = (effect) => {
  if (effect.type === "DROP_SHADOW" || effect.type === "INNER_SHADOW") return Boolean(effect.hex);
  if (effect.type === "LAYER_BLUR" || effect.type === "BACKGROUND_BLUR") return typeof effect.blur === "number";
  return false;
};
var mapContainer = (node, ctx) => {
  const solidFill = node.style.fills.find((f) => f.type === "SOLID" && f.hex);
  const backgroundColorSlug = solidFill?.variableRef ? ctx.colorSlugByVariableRef?.get(solidFill.variableRef) : void 0;
  const paintableFill = node.style.fills.find((f) => (f.type === "SOLID" || f.type === "GRADIENT") && f.hex);
  const unmappedEffects = node.style.effects.filter((e) => !isEffectMapped(e));
  if (unmappedEffects.length > 0) {
    warn(
      ctx,
      node.id,
      `${unmappedEffects.length} effect(s) not mapped \u2014 unsupported effect type or missing required data (see D70).`
    );
  }
  if (node.style.strokes.length > 1) {
    warn(ctx, node.id, "Multiple strokes present \u2014 only the first is rendered.");
  }
  if (node.style.fills.length > 1) {
    warn(ctx, node.id, "Multiple fill layers present \u2014 only the top paintable fill (solid or gradient) is rendered.");
  }
  if (paintableFill?.type === "GRADIENT" && !paintableFill.gradient) {
    warn(
      ctx,
      node.id,
      "Gradient fill has no CSS-representable geometry (e.g. GRADIENT_DIAMOND) \u2014 rendered as a flat fallback color instead of a real gradient (see D69)."
    );
  }
  const hasAbsoluteChild = node.children.some((child) => Boolean(child.layout.position));
  const needsPositionedAnchor = hasAbsoluteChild && !node.layout.position;
  const backgroundAsset = node.backgroundAssetRef ? ctx.assetsById.get(node.backgroundAssetRef) : void 0;
  if (node.backgroundAssetRef && !backgroundAsset) {
    warn(ctx, node.id, `Node has no resolvable background asset (backgroundAssetRef: ${node.backgroundAssetRef}) \u2014 background image omitted.`);
  }
  const backgroundImageDeclaration = backgroundAsset ? `background-image: url('assets/${backgroundAsset.fileName.replace(/^assets\//, "")}'); background-size: cover; background-position: center` : void 0;
  const declarations = joinStyles(
    layoutToDeclarations(node.layout, node.paintOrder),
    // D60: matches `!important` on `position: absolute` in
    // `layoutToDeclarations` (styleHelpers.ts) — this element's own
    // `position` here happens to already agree with what Gutenberg's
    // editor CSS wants (`relative`), so there's no confirmed live
    // conflict for this exact declaration today, but defending it too is
    // cheap insurance against some other, not-yet-observed editor rule
    // asserting a different `position` value on a container.
    needsPositionedAnchor ? "position: relative !important" : void 0,
    nodeStyleToDeclarations(node.style, Boolean(backgroundColorSlug)),
    backgroundImageDeclaration
  );
  const nodeClass = nodeClassFor(node.id);
  addRule(ctx.stylesheet, nodeClass, declarations);
  const customClass = declarations ? nodeClass : void 0;
  const attrs = {};
  if (backgroundColorSlug) attrs.backgroundColor = backgroundColorSlug;
  if (customClass) attrs.className = customClass;
  const wrapperClassName = [
    "wp-block-group",
    customClass,
    backgroundColorSlug ? `has-background has-${backgroundColorSlug}-background-color` : void 0
  ].filter(Boolean).join(" ") || void 0;
  if (node.children.length === 0) {
    return {
      blockName: "core/html",
      attrs: {},
      tagName: "div",
      className: wrapperClassName,
      innerHtml: ""
    };
  }
  return {
    blockName: "core/group",
    attrs,
    tagName: "div",
    className: wrapperClassName,
    children: node.children.map((child) => mapDesignNode(child, ctx))
  };
};
var asRenderRoot = (node) => ({
  ...node,
  layout: { ...node.layout, position: void 0 }
});
var mapDesignNode = (node, ctx) => {
  switch (node.type) {
    case "TEXT": {
      const detectedTextLink = detectLink(node);
      if (detectedTextLink) {
        return renderLink(detectedTextLink, ctx);
      }
      return mapText(node, ctx);
    }
    case "IMAGE":
    case "VECTOR":
      return mapImageLike(node, ctx);
    case "FRAME": {
      const detectedForm = detectForm(node, (message) => warn(ctx, node.id, message));
      if (detectedForm) {
        return renderForm(detectedForm, ctx);
      }
      const detectedFrameLink = detectLink(node, (message) => warn(ctx, node.id, message));
      if (detectedFrameLink) {
        return renderLink(detectedFrameLink, ctx);
      }
      return mapContainer(node, ctx);
    }
    case "RECTANGLE":
      return mapContainer(node, ctx);
    default: {
      warn(ctx, node.id, `Unrecognized node type "${node.type}" \u2014 rendered as an empty group.`);
      return { blockName: "core/group", attrs: {}, tagName: "div", children: [] };
    }
  }
};

// src/blocks/types.ts
var isRawBlockChild = (child) => typeof child.renderRaw === "function";

// src/blocks/render.ts
var stripCorePrefix = (blockName) => blockName.replace(/^core\//, "");
var attrsToJson = (attrs) => {
  const clean = Object.fromEntries(Object.entries(attrs).filter(([, v]) => v !== void 0));
  return Object.keys(clean).length > 0 ? ` ${JSON.stringify(clean)}` : "";
};
var attrString = (attrs) => attrs ? Object.entries(attrs).filter(([, v]) => v !== void 0).map(([k, v]) => ` ${k}="${v}"`).join("") : "";
var indentStr = (depth) => "  ".repeat(depth);
var renderBlock = (block, depth = 0) => {
  const name = stripCorePrefix(block.blockName);
  const attrsJson = attrsToJson(block.attrs);
  const indent = indentStr(depth);
  const classAndStyle = attrString({
    class: block.className,
    style: block.inlineStyle
  });
  if (block.isVoid) {
    const img = `<${block.tagName}${attrString(block.extraAttrs)}/>`;
    const inner = block.wrapperTagName ? `<${block.wrapperTagName}${attrString({ class: block.wrapperClassName })}>${img}</${block.wrapperTagName}>` : img;
    return `${indent}<!-- wp:${name}${attrsJson} -->
${indent}${inner}
${indent}<!-- /wp:${name} -->`;
  }
  if (block.children) {
    const childrenHtml = block.children.map((child) => isRawBlockChild(child) ? child.renderRaw(depth + 1) : renderBlock(child, depth + 1)).join("\n");
    return `${indent}<!-- wp:${name}${attrsJson} -->
${indent}<${block.tagName}${classAndStyle}>
${childrenHtml}
${indent}</${block.tagName}>
${indent}<!-- /wp:${name} -->`;
  }
  if (block.blockName === "core/html" && !classAndStyle) {
    return `${indent}<!-- wp:html -->
${indent}${block.innerHtml ?? ""}
${indent}<!-- /wp:html -->`;
  }
  return `${indent}<!-- wp:${name}${attrsJson} -->
${indent}<${block.tagName}${classAndStyle}>${block.innerHtml ?? ""}</${block.tagName}>
${indent}<!-- /wp:${name} -->`;
};

// src/theme/templateParts.ts
var heightOf = (node) => typeof node.layout.sizing.height === "number" ? node.layout.sizing.height : Number.POSITIVE_INFINITY;
var pickTopmostChild = (children) => {
  const positioned = children.filter((c) => c.layout.position);
  if (positioned.length === 0) return children[0];
  return positioned.reduce((top, c) => {
    const cy = c.layout.position.y;
    const ty = top.layout.position.y;
    if (cy !== ty) return cy < ty ? c : top;
    return heightOf(c) < heightOf(top) ? c : top;
  });
};
var pickBottommostChild = (children) => {
  if (children.length <= 1) return void 0;
  const positioned = children.filter((c) => c.layout.position);
  if (positioned.length === 0) return children[children.length - 1];
  return positioned.reduce((bottom, c) => {
    const cy = c.layout.position.y;
    const by = bottom.layout.position.y;
    if (cy !== by) return cy > by ? c : bottom;
    return heightOf(c) < heightOf(bottom) ? c : bottom;
  });
};
var classifyTemplateParts = (bundle) => {
  const total = bundle.designs.length;
  if (total === 0) return {};
  const tally = (pick) => {
    const votes = /* @__PURE__ */ new Map();
    for (const design of bundle.designs) {
      const candidate = pick(design.root.children);
      if (!candidate?.componentId) continue;
      const entry = votes.get(candidate.componentId) ?? { count: 0, node: candidate };
      entry.count += 1;
      votes.set(candidate.componentId, entry);
    }
    let best;
    for (const [componentId, { count, node }] of votes) {
      if (!best || count > best.count) best = { componentId, count, node };
    }
    if (best && best.count > total / 2) {
      return { componentId: best.componentId, node: best.node, voteCount: best.count };
    }
    return void 0;
  };
  return {
    header: tally((children) => pickTopmostChild(children)),
    // Guard against a 1-child root voting for the same node as both header
    // and footer — a design with only one root child can't sensibly have
    // both. Also guards the position-based pick: if the topmost and
    // bottommost candidates resolve to the very same node (e.g. only one
    // child carries position data), footer isn't a sensible second vote.
    footer: tally((children) => {
      const bottom = pickBottommostChild(children);
      const top = pickTopmostChild(children);
      return bottom && bottom.id !== top?.id ? bottom : void 0;
    })
  };
};
var templatePartInclusion = (area, zIndex, stylesheet) => ({
  renderRaw: (depth) => {
    const indent = indentStr(depth);
    const wrapperClass = `tpl-part-${area}`;
    if (zIndex !== void 0 && stylesheet) {
      addRule(stylesheet, wrapperClass, `position: relative; z-index: ${zIndex}`);
    }
    return `${indent}<!-- wp:template-part {"slug":"${area}","area":"${area}","className":"${wrapperClass}"} /-->`;
  }
});

// src/theme/generateThemeTokens.ts
var buildThemeTokens = (bundle) => {
  const colorEntries = Object.entries(bundle.styles.colors);
  const colorSlugs = assignUniqueSlugs(
    colorEntries.map(([, style]) => style.name),
    toPresetSlug
  );
  const colorPalette = [];
  const colorSlugByVariableRef = /* @__PURE__ */ new Map();
  colorEntries.forEach(([variableId, style], i) => {
    const slug = colorSlugs[i];
    colorPalette.push({ slug, color: style.hex, name: style.name });
    colorSlugByVariableRef.set(variableId, slug);
  });
  const textStyleEntries = Object.entries(bundle.styles.textStyles);
  const fontSizeSlugs = assignUniqueSlugs(
    textStyleEntries.map(([, style]) => style.name),
    toPresetSlug
  );
  const fontSizes = [];
  const fontSizeSlugByTextStyleId = /* @__PURE__ */ new Map();
  textStyleEntries.forEach(([textStyleId, style], i) => {
    const slug = fontSizeSlugs[i];
    fontSizes.push({ slug, size: `${style.fontSize}px`, name: style.name });
    fontSizeSlugByTextStyleId.set(textStyleId, slug);
  });
  const familySlugs = /* @__PURE__ */ new Map();
  for (const [, style] of textStyleEntries) {
    if (style.fontFamily && !familySlugs.has(style.fontFamily)) {
      familySlugs.set(style.fontFamily, toPresetSlug(style.fontFamily));
    }
  }
  const fontFamilies = Array.from(familySlugs, ([fontFamily, slug]) => ({
    slug,
    fontFamily,
    name: fontFamily
  }));
  return { colorPalette, fontSizes, fontFamilies, colorSlugByVariableRef, fontSizeSlugByTextStyleId };
};

// src/cliVersion.ts
import { existsSync, readFileSync as readFileSync2 } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";
var cached;
var getCliVersion = () => {
  if (cached) return cached;
  let dir = dirname(fileURLToPath(import.meta.url));
  for (let i = 0; i < 6; i++) {
    const candidate = join(dir, "package.json");
    if (existsSync(candidate)) {
      try {
        const pkg = JSON.parse(readFileSync2(candidate, "utf-8"));
        if (pkg.name === "wp-figma-gen" && typeof pkg.version === "string") {
          cached = pkg.version;
          return cached;
        }
      } catch {
      }
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  console.warn('[wp-figma-gen] Could not resolve own package.json version \u2014 falling back to "0.0.0".');
  cached = "0.0.0";
  return cached;
};

// src/theme/googleFonts.ts
var MODERN_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
var NAMED_WEIGHTS = {
  thin: "100",
  hairline: "100",
  extralight: "200",
  ultralight: "200",
  light: "300",
  regular: "400",
  normal: "400",
  book: "400",
  medium: "500",
  semibold: "600",
  demibold: "600",
  bold: "700",
  extrabold: "800",
  ultrabold: "800",
  black: "900",
  heavy: "900"
};
var normalizeFontWeight = (fontWeight) => {
  const trimmed = fontWeight.trim();
  if (/^\d+$/.test(trimmed)) return trimmed;
  const named = NAMED_WEIGHTS[trimmed.toLowerCase().replace(/\s+/g, "")];
  return named ?? "400";
};
var collectFontRequests = (bundle) => {
  const requests = /* @__PURE__ */ new Map();
  const visit = (node) => {
    const first = node.text?.segments?.[0];
    if (first?.fontFamily) {
      const weights = requests.get(first.fontFamily) ?? /* @__PURE__ */ new Set();
      weights.add(normalizeFontWeight(first.fontWeight));
      requests.set(first.fontFamily, weights);
    }
    node.children.forEach(visit);
  };
  bundle.designs.forEach((design) => visit(design.root));
  return requests;
};
var slugifyFontFamily = (family) => family.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
var parseFontFaceRules = (css) => {
  const rules = [];
  for (const match of css.matchAll(/@font-face\s*{([^}]*)}/g)) {
    const block = match[1];
    const family = /font-family:\s*['"]?([^;'"]+)['"]?/.exec(block)?.[1]?.trim();
    const weight = /font-weight:\s*(\d+)/.exec(block)?.[1] ?? "400";
    const style = /font-style:\s*(\w+)/.exec(block)?.[1] ?? "normal";
    const unicodeRange = /unicode-range:\s*([^;]+);/.exec(block)?.[1]?.trim();
    const srcUrl = /src:\s*url\(([^)]+)\)\s*format\(['"]woff2['"]\)/.exec(block)?.[1]?.trim();
    if (family && srcUrl) rules.push({ family, weight, style, unicodeRange, srcUrl });
  }
  return rules;
};
var resolveGoogleFonts = async (requests, warn2, fetchImpl = fetch) => {
  const faces = [];
  const resolvedFamilies = [];
  const unresolvedFamilies = [];
  for (const [family, weightsSet] of requests) {
    const weights = Array.from(weightsSet).sort();
    let css;
    try {
      const url = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family)}:wght@${weights.join(";")}&display=swap`;
      const res = await fetchImpl(url, { headers: { "User-Agent": MODERN_UA } });
      if (!res.ok) {
        unresolvedFamilies.push(family);
        warn2(`Font "${family}" not found on Google Fonts (HTTP ${res.status}) \u2014 falling back to a generic CSS font-family (D37).`);
        continue;
      }
      css = await res.text();
    } catch (error) {
      unresolvedFamilies.push(family);
      warn2(`Could not reach Google Fonts for "${family}" (${error.message}) \u2014 falling back to a generic CSS font-family (D37).`);
      continue;
    }
    const parsed = parseFontFaceRules(css);
    if (parsed.length === 0) {
      unresolvedFamilies.push(family);
      warn2(`Google Fonts returned no usable (woff2) @font-face rules for "${family}" \u2014 falling back to a generic CSS font-family (D37).`);
      continue;
    }
    let familyResolved = false;
    let subsetIndex = 0;
    for (const rule of parsed) {
      try {
        const fileRes = await fetchImpl(rule.srcUrl);
        if (!fileRes.ok) {
          warn2(`Font file download failed for "${family}" weight ${rule.weight} (HTTP ${fileRes.status}).`);
          continue;
        }
        const bytes = new Uint8Array(await fileRes.arrayBuffer());
        const fileName = `${slugifyFontFamily(family)}-${rule.weight}-${rule.style}-${subsetIndex}.woff2`;
        subsetIndex += 1;
        faces.push({ family, weight: rule.weight, style: rule.style, unicodeRange: rule.unicodeRange, fileName, bytes });
        familyResolved = true;
      } catch (error) {
        warn2(`Font file download failed for "${family}" weight ${rule.weight} (${error.message}).`);
      }
    }
    if (familyResolved) resolvedFamilies.push(family);
    else unresolvedFamilies.push(family);
  }
  return { faces, resolvedFamilies, unresolvedFamilies };
};
var fontFaceCss = (faces) => faces.map(
  (f) => `@font-face {
  font-family: "${f.family}";
  font-style: ${f.style};
  font-weight: ${f.weight};
  font-display: swap;
  src: url("assets/fonts/${f.fileName}") format("woff2");${f.unicodeRange ? `
  unicode-range: ${f.unicodeRange};` : ""}
}`
).join("\n\n");

// src/theme/generateThemeFiles.ts
var FALLBACK_INDEX_TEMPLATE = `<!-- wp:group -->
<div class="wp-block-group">
<!-- wp:paragraph -->
<p>This is the theme's fallback template \u2014 WordPress's template hierarchy applies templates/page.html to every ordinary Page automatically, so this only renders for content types that fall through to index.html. Create a new Page and use "Choose a pattern" to insert one of this theme's starter layouts as that Page's own content.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
`;
var thinScaffoldTemplateHtml = (headerHtml, footerHtml) => `${[
  headerHtml,
  `<!-- wp:group {"tagName":"main","layout":{"type":"constrained"}} -->
<main class="wp-block-group">
<!-- wp:post-content {"layout":{"type":"constrained"}} /-->
</main>
<!-- /wp:group -->`,
  footerHtml
].filter(Boolean).join("\n\n")}
`;
var nextThemeVersion = (outDir) => {
  const cliVersion = getCliVersion();
  const [cliMajor = "0", cliMinor = "0"] = cliVersion.split(".");
  const freshVersion = `${cliMajor}.${cliMinor}.0`;
  const stylePath = join2(outDir, "style.css");
  if (!existsSync2(stylePath)) return freshVersion;
  const previous = readFileSync3(stylePath, "utf-8");
  const match = previous.match(/^Version:\s*(\d+)\.(\d+)\.(\d+)\s*$/m);
  if (!match) return freshVersion;
  const [, prevMajor, prevMinor, prevPatch] = match;
  if (prevMajor !== cliMajor || prevMinor !== cliMinor) return freshVersion;
  return `${cliMajor}.${cliMinor}.${Number(prevPatch) + 1}`;
};
var styleCssHeader = (bundle, version, themeNameOverride) => `/*
Theme Name: ${themeNameOverride || bundle.meta.figmaFileName || "Generated Theme"} (wp-figma-gen)
Description: Generated by wp-figma-gen from a Design Bundle exported from Figma (${bundle.meta.figmaFileName || "unknown source"}, page "${bundle.meta.figmaPageName || "unknown"}"). Regenerating will overwrite hand edits to templates/*.html \u2014 edit theme.json / style.css for anything meant to survive a re-run.
Version: ${version}
Requires at least: 6.4
Requires PHP: 7.4
*/
`;
var TEMPLATE_PART_TITLES = { header: "Header", footer: "Footer" };
var patternCategorySlugFor = (themeSlug) => `${themeSlug}-page`;
var CHROME_Z_INDEX = 1e3;
var functionsPhpContent = (themeSlug, version) => `<?php
/**
 * Theme functions and definitions.
 *
 * Generated by wp-figma-gen. WordPress block themes do not automatically
 * enqueue style.css the way classic themes' header.php did \u2014 this file's
 * job is to load it, both on the front end and inside the block editor
 * (D36/D39). Regenerating this theme overwrites this file; add anything
 * meant to survive a re-run to a separate must-use plugin or a child
 * theme instead.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'${themeSlug}-style',
		get_stylesheet_uri(),
		array(),
		'${version}'
	);
} );

// D39: wp_enqueue_scripts above never fires inside the block editor (the
// per-Page/Post editor or the Site Editor's template views) \u2014 this is
// WordPress's separate, documented mechanism for loading a theme's own
// stylesheet there too, so templates look the same in the editor as they
// do on the live page.
add_action( 'after_setup_theme', function () {
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );
} );

// D40: WordPress 7.0 defaults unsynced patterns (what every generated
// design's content is, per D31) to "contentOnly" editing \u2014 any block
// without an explicit "role":"content" attribute (every core/group this
// project generates; group has no content role by design, it's a pure
// layout wrapper) is hidden from List View and the canvas. Nearly this
// entire project's output is nested core/group wrappers, so contentOnly
// mode collapses almost everything down to invisible. Opting back out to
// match this project's actual editing model (raw block structure, not a
// simplified end-user content-editing surface) for unsynced patterns only
// \u2014 template parts (header/footer) intentionally stay as opaque "section"
// blocks either way; that's a separate mechanism this setting doesn't
// reach, and isn't a problem this project needs to solve.
add_filter( 'block_editor_settings_all', function ( $settings ) {
	$settings['disableContentOnlyForUnsyncedPatterns'] = true;
	return $settings;
} );

// D61: registers the pattern category every design's starter-content
// pattern is filed under (see writeStarterPatternFile's Categories:
// header field) \u2014 same convention Twenty Twenty-Five uses for its own
// "Pages" starter-pattern category (register_block_pattern_category,
// confirmed directly against that theme's real functions.php). This is
// what makes WordPress's native "Choose a pattern" modal group these
// patterns sensibly instead of leaving them uncategorized.
add_action( 'init', function () {
	register_block_pattern_category(
		'${patternCategorySlugFor(themeSlug)}',
		array(
			'label'       => __( 'Pages', '${themeSlug}' ),
			'description' => __( 'Starter layouts generated from this theme\\'s Figma designs.', '${themeSlug}' ),
		)
	);
} );
`;
var writePatternFile = (patternsDir, patternSlug, title, body) => {
  const php = `<?php
/**
 * Title: ${title}
 * Slug: ${patternSlug}
 * Inserter: no
 */
?>
${body}
`;
  writeFileSync(join2(patternsDir, `${patternSlug.split("/").pop()}.php`), php);
};
var patternInclusion = (patternSlug) => `<!-- wp:pattern {"slug":"${patternSlug}"} /-->`;
var writeStarterPatternFile = (patternsDir, patternSlug, title, body, categorySlug) => {
  const php = `<?php
/**
 * Title: ${title}
 * Slug: ${patternSlug}
 * Categories: ${categorySlug}
 * Block Types: core/post-content
 * Post Types: page, wp_template
 */
?>
${body}
`;
  writeFileSync(join2(patternsDir, `${patternSlug.split("/").pop()}.php`), php);
};
var explicitHeight = (node) => typeof node.layout.sizing.height === "number" ? node.layout.sizing.height : 0;
var pruneTemplatePartChildren = (root, parts) => {
  let children = [...root.children];
  const removed = [];
  let topShift = 0;
  let bottomTrim = 0;
  let headerPaintOrder;
  let footerPaintOrder;
  if (parts.header) {
    const headerChild = pickTopmostChild(children);
    if (headerChild?.componentId === parts.header.componentId) {
      children = children.filter((c) => c.id !== headerChild.id);
      removed.push("header");
      topShift = explicitHeight(headerChild);
      headerPaintOrder = headerChild.paintOrder;
    }
  }
  if (parts.footer) {
    const footerChild = pickBottommostChild(children);
    if (footerChild?.componentId === parts.footer.componentId) {
      children = children.filter((c) => c.id !== footerChild.id);
      removed.push("footer");
      bottomTrim = explicitHeight(footerChild);
      footerPaintOrder = footerChild.paintOrder;
    }
  }
  if (topShift > 0) {
    children = children.map(
      (child) => child.layout.position ? { ...child, layout: { ...child.layout, position: { ...child.layout.position, y: child.layout.position.y - topShift } } } : child
    );
  }
  return { children, removed, heightAdjustment: topShift + bottomTrim, headerPaintOrder, footerPaintOrder };
};
var generateThemeFiles = async (bundle, assets, outDir, themeSlugOverride, options) => {
  const downloadFonts = options?.downloadFonts ?? true;
  const themeNameOverride = options?.themeName;
  const templatesDir = join2(outDir, "templates");
  const assetsDir = join2(outDir, "assets");
  const patternsDir = join2(outDir, "patterns");
  mkdirSync(templatesDir, { recursive: true });
  mkdirSync(assetsDir, { recursive: true });
  mkdirSync(patternsDir, { recursive: true });
  for (const [fileName, bytes] of Object.entries(assets)) {
    const baseName = fileName.replace(/^assets\//, "");
    writeFileSync(join2(assetsDir, baseName), bytes);
  }
  const themeSlug = themeSlugOverride || toSlug(bundle.meta.figmaFileName || "generated-theme");
  const slugs = assignUniqueSlugs(bundle.designs.map((d) => d.layerName));
  const assetsById = new Map(bundle.assets.map((a) => [a.id, a]));
  const warnings = [];
  const tokens = buildThemeTokens(bundle);
  const stylesheet = createStylesheet();
  const mapCtx = () => ({
    assetsById,
    warnings,
    textStyles: bundle.styles.textStyles,
    colorSlugByVariableRef: tokens.colorSlugByVariableRef,
    fontSizeSlugByTextStyleId: tokens.fontSizeSlugByTextStyleId,
    stylesheet
  });
  const templateParts = classifyTemplateParts(bundle);
  if (templateParts.header || templateParts.footer) {
    const partsDir = join2(outDir, "parts");
    mkdirSync(partsDir, { recursive: true });
    ["header", "footer"].forEach((area) => {
      const candidate = templateParts[area];
      if (!candidate) return;
      const block = mapDesignNode(asRenderRoot(candidate.node), mapCtx());
      const patternSlug = `${themeSlug}/${area}`;
      writePatternFile(patternsDir, patternSlug, TEMPLATE_PART_TITLES[area], renderBlock(block));
      writeFileSync(join2(partsDir, `${area}.html`), `${patternInclusion(patternSlug)}
`);
    });
  }
  bundle.designs.forEach((design, index) => {
    const slug = slugs[index];
    const { children, heightAdjustment } = pruneTemplatePartChildren(design.root, templateParts);
    const prunedHeight = heightAdjustment > 0 && typeof design.root.layout.sizing.height === "number" ? Math.max(0, design.root.layout.sizing.height - heightAdjustment) : design.root.layout.sizing.height;
    const prunedRoot = {
      ...design.root,
      layout: { ...design.root.layout, sizing: { ...design.root.layout.sizing, height: prunedHeight } },
      children
    };
    const block = mapDesignNode(asRenderRoot(prunedRoot), mapCtx());
    const patternSlug = `${themeSlug}/${slug}`;
    writeStarterPatternFile(
      patternsDir,
      patternSlug,
      design.layerName,
      renderBlock(block),
      patternCategorySlugFor(themeSlug)
    );
  });
  const headerHtml = templateParts.header ? templatePartInclusion("header", CHROME_Z_INDEX, stylesheet).renderRaw(0) : void 0;
  const footerHtml = templateParts.footer ? templatePartInclusion("footer", CHROME_Z_INDEX, stylesheet).renderRaw(0) : void 0;
  writeFileSync(join2(templatesDir, "page.html"), thinScaffoldTemplateHtml(headerHtml, footerHtml));
  writeFileSync(join2(templatesDir, "index.html"), FALLBACK_INDEX_TEMPLATE);
  let fontFacesBlock = "";
  const fontsResult = downloadFonts ? await resolveGoogleFonts(collectFontRequests(bundle), (message) => warnings.push({ nodeId: "<fonts>", message })) : { faces: [], resolvedFamilies: [], unresolvedFamilies: [] };
  if (fontsResult.faces.length > 0) {
    const fontsDir = join2(assetsDir, "fonts");
    mkdirSync(fontsDir, { recursive: true });
    for (const face of fontsResult.faces) {
      writeFileSync(join2(fontsDir, face.fileName), face.bytes);
    }
    fontFacesBlock = `${fontFaceCss(fontsResult.faces)}

`;
  }
  const rules = renderStylesheet(stylesheet);
  const version = nextThemeVersion(outDir);
  writeFileSync(
    join2(outDir, "style.css"),
    styleCssHeader(bundle, version, themeNameOverride) + (fontFacesBlock ? `
${fontFacesBlock}` : "") + (rules ? `
${rules}
` : "")
  );
  writeFileSync(join2(outDir, "functions.php"), functionsPhpContent(themeSlug, version));
  const themeJson = {
    $schema: "https://schemas.wp.org/trunk/theme.json",
    version: 3,
    settings: {
      appearanceTools: true,
      // Real Figma-derived design tokens (generateThemeTokens.ts), not the
      // empty-palette bootstrap this shipped as before. Populated from
      // bundle.styles.colors/textStyles — empty arrays when the bundle has
      // none (matches theme.json's own shape either way, no conditional
      // omission needed).
      color: { palette: tokens.colorPalette },
      typography: { fontSizes: tokens.fontSizes, fontFamilies: tokens.fontFamilies },
      // D50: every generated `core/group` gets WordPress's own
      // `is-layout-flow wp-block-group-is-layout-flow` classes automatically
      // — Gutenberg's block-supports system defaults a block's `layout` to
      // "flow" whenever no explicit `layout` attr overrides it (D27
      // deliberately never sets one, since WP's own layout support was
      // never being correctly reproduced in the first place — the whole
      // reason everything moved to hand-rolled CSS). That default "flow"
      // layout generates a real, global stylesheet rule —
      // `.wp-block-group-is-layout-flow > * + * { margin-block-start:
      // {blockGap} }` — which only targets *non-first* children (a
      // `* + *` adjacent-sibling selector). Confirmed on a real page: a
      // horizontal nav row of "Page"/"Page"/"Page"/Button, all four
      // sharing byte-for-byte identical CSS from our own stylesheet —
      // Sean's own dev-tools inspection confirmed `margin-block-start: 0`
      // on the first item vs. `24px` on the rest. That extra top-only
      // margin was stacking on top of (not replacing) our own flex `gap`
      // declaration, and pushed `align-items: center`'s vertical
      // centering off for every item but the first. We already fully own
      // spacing via our own generated flex/gap/margin CSS everywhere —
      // WP's native block-gap contribution is never wanted, on any
      // block, anywhere in a generated theme.
      //
      // `blockGap: null` (NOT `false`) is required here — checked
      // WordPress's own theme.json docs before shipping this rather than
      // assuming: `false` only hides the *editor UI control*, it still
      // outputs the block-gap CSS (`WordPress-generated CSS: Yes` in the
      // docs' own settings table); only `null` — theme.json's actual
      // default, which this project's `appearanceTools: true` above was
      // silently overriding to `true` — disables the generated CSS
      // itself. An explicit `null` here overrides `appearanceTools`'s
      // broad shorthand-enablement, since specific settings always win
      // over what a shorthand would have implied.
      spacing: { blockGap: null }
    }
    // D67: no `customTemplates` entry anymore — there's only ever one
    // Template (`templates/page.html`), which WordPress's own template
    // hierarchy applies to every Page automatically. `customTemplates` is
    // specifically how a theme registers *additional, named* Templates a
    // Page author can pick from (confirmed against Twenty Twenty-Five's own
    // theme.json, which lists exactly the templates that aren't already
    // covered by hierarchy auto-mapping) — with none left to register, this
    // key is correctly just absent, not an empty array.
  };
  const templatePartEntries = ["header", "footer"].filter((area) => templateParts[area]).map((area) => ({ name: area, title: TEMPLATE_PART_TITLES[area], area }));
  if (templatePartEntries.length > 0) {
    themeJson.templateParts = templatePartEntries;
  }
  writeFileSync(join2(outDir, "theme.json"), `${JSON.stringify(themeJson, null, 2)}
`);
  return {
    outDir,
    patternSlugs: slugs,
    warnings,
    templateParts,
    themeSlug,
    fonts: { resolvedFamilies: fontsResult.resolvedFamilies, unresolvedFamilies: fontsResult.unresolvedFamilies }
  };
};

// src/commands/theme.ts
var generateTheme = async (loaded, outDir, themeSlug, downloadFonts = true, themeName) => {
  const { bundle, assets } = loaded;
  console.log(`[theme] Loaded bundle "${bundle.meta.figmaFileName}" (schemaVersion ${bundle.schemaVersion})`);
  console.log(`[theme] ${bundle.designs.length} design(s): ${bundle.designs.map((d) => d.layerName).join(", ")}`);
  console.log(`[theme] ${Object.keys(assets).length} asset(s) resolved`);
  if (themeName) {
    console.log(`[theme] Theme Name overridden to "${themeName}" (bundle's own name was "${bundle.meta.figmaFileName}")`);
  }
  const result = await generateThemeFiles(bundle, assets, outDir, themeSlug, { downloadFonts, themeName });
  console.log(
    `[theme] Bundled image assets are referenced from patterns/*.php via get_stylesheet_directory_uri() (D31) \u2014 resolves correctly on any domain or install path, no folder-name matching required.`
  );
  console.log(
    `[theme] Wrote 1 shared template (page.html) + ${result.patternSlugs.length} starter pattern(s) + theme.json + style.css + functions.php + patterns/ to "${outDir}"`
  );
  console.log(
    `[theme] functions.php enqueues style.css (D36) \u2014 WordPress block themes don't load it automatically. If you're re-activating an already-installed copy of this theme, WordPress may still be serving files from before this fix; re-upload/re-activate to pick up functions.php.`
  );
  console.log(`[theme] Starter pattern slugs: ${result.patternSlugs.join(", ")}`);
  if (result.fonts.resolvedFamilies.length > 0) {
    console.log(
      `[theme] Self-hosted ${result.fonts.resolvedFamilies.length} font famil${result.fonts.resolvedFamilies.length === 1 ? "y" : "ies"} from Google Fonts (D38): ${result.fonts.resolvedFamilies.join(", ")} -> assets/fonts/`
    );
  }
  if (result.fonts.unresolvedFamilies.length > 0) {
    console.warn(
      `[theme] Could not resolve from Google Fonts, falling back to a generic CSS font-family (D37): ${result.fonts.unresolvedFamilies.join(", ")}`
    );
  }
  const { header, footer } = result.templateParts;
  if (header) {
    console.log(`[theme] Detected header Template Part (componentId ${header.componentId}, ${header.voteCount}/${bundle.designs.length} design(s)) -> parts/header.html`);
  }
  if (footer) {
    console.log(`[theme] Detected footer Template Part (componentId ${footer.componentId}, ${footer.voteCount}/${bundle.designs.length} design(s)) -> parts/footer.html`);
  }
  const mappingWarnings = result.warnings.filter((w) => w.nodeId !== "<fonts>");
  if (mappingWarnings.length > 0) {
    console.warn(`[theme] ${mappingWarnings.length} mapping warning(s):`);
    for (const w of mappingWarnings) {
      console.warn(`[theme]   - [${w.nodeId}] ${w.message}`);
    }
  }
};

// src/patterns/generatePatternFiles.ts
import { mkdirSync as mkdirSync2, writeFileSync as writeFileSync2 } from "fs";
import { join as join3 } from "path";
var buildPatternJson = (title, content) => ({
  __file: "wp_block",
  title,
  content,
  syncStatus: ""
});
var generatePatternFiles = (bundle, assets, outDir, assetBaseUrl) => {
  const assetsDir = join3(outDir, "assets");
  mkdirSync2(outDir, { recursive: true });
  mkdirSync2(assetsDir, { recursive: true });
  for (const [fileName, bytes] of Object.entries(assets)) {
    const baseName = fileName.replace(/^assets\//, "");
    writeFileSync2(join3(assetsDir, baseName), bytes);
  }
  const slugs = assignUniqueSlugs(bundle.designs.map((d) => d.layerName));
  const assetsById = new Map(bundle.assets.map((a) => [a.id, a]));
  const warnings = [];
  const stylesheet = createStylesheet();
  const imageSrcMode = { kind: "url", baseUrl: assetBaseUrl };
  bundle.designs.forEach((design, index) => {
    const slug = slugs[index];
    const block = mapDesignNode(asRenderRoot(design.root), {
      assetsById,
      warnings,
      stylesheet,
      imageSrcMode
      // No textStyles / colorSlugByVariableRef / fontSizeSlugByTextStyleId
      // — see this module's doc comment, point 2.
    });
    const content = renderBlock(block);
    const json = buildPatternJson(design.layerName, content);
    writeFileSync2(join3(outDir, `${slug}.json`), `${JSON.stringify(json, null, 2)}
`);
  });
  const cssFileName = "wp-figma-gen-patterns.css";
  const rules = renderStylesheet(stylesheet);
  writeFileSync2(join3(outDir, cssFileName), rules ? `${rules}
` : "");
  return {
    outDir,
    patternSlugs: slugs,
    warnings,
    assetBaseUrl,
    cssFileName,
    assetCount: Object.keys(assets).length
  };
};

// src/commands/patterns.ts
var generatePatterns = (loaded, outDir, assetBaseUrl) => {
  const { bundle, assets } = loaded;
  console.log(`[patterns] Loaded bundle "${bundle.meta.figmaFileName}" (schemaVersion ${bundle.schemaVersion})`);
  console.log(`[patterns] ${bundle.designs.length} design(s): ${bundle.designs.map((d) => d.layerName).join(", ")}`);
  console.log(`[patterns] ${Object.keys(assets).length} asset(s) resolved`);
  const resolvedAssetBaseUrl = assetBaseUrl || DEFAULT_ASSET_BASE_URL;
  const result = generatePatternFiles(bundle, assets, outDir, resolvedAssetBaseUrl);
  console.log(`[patterns] Wrote ${result.patternSlugs.length} pattern JSON file(s) to "${outDir}"`);
  console.log(`[patterns] Pattern slugs: ${result.patternSlugs.join(", ")}`);
  if (!assetBaseUrl) {
    console.warn(
      `[patterns] --asset-base-url not set \u2014 defaulted to "${resolvedAssetBaseUrl}". This is a guess, not a verified path: upload this run's "${result.outDir}/assets" folder so it's reachable at exactly that URL, or re-run with --asset-base-url pointed at wherever the assets actually end up (Media Library, a theme folder, etc.) and regenerate. Unlike theme mode, patterns mode cannot resolve this automatically \u2014 imported pattern content has no PHP execution available to look it up live (see D31 vs. the Phase 4 decision in 02-decisions-log.md).`
    );
  } else {
    console.log(`[patterns] Image src base URL: "${resolvedAssetBaseUrl}" \u2014 upload "${result.outDir}/assets" there.`);
  }
  console.log(
    `[patterns] Generated layout/color/spacing CSS was written to "${result.cssFileName}" \u2014 WordPress does not auto-load a stylesheet for imported pattern content the way it does a block theme's style.css. Add this file's contents to your active theme's stylesheet (or enqueue it separately) for these patterns to render with correct styling, not just correct markup.`
  );
  if (result.warnings.length > 0) {
    console.warn(`[patterns] ${result.warnings.length} mapping warning(s):`);
    for (const w of result.warnings) {
      console.warn(`[patterns]   - [${w.nodeId}] ${w.message}`);
    }
  }
};

// src/index.ts
var main = async (argv) => {
  if (argv.includes("--version") || argv.includes("-v")) {
    console.log(getCliVersion());
    return;
  }
  const args = parseCliArgs(argv);
  const loaded = loadDesignBundle(args.bundlePath);
  if (args.mode === "theme") {
    await generateTheme(loaded, args.outDir, args.themeSlug, args.downloadFonts, args.themeName);
  } else {
    generatePatterns(loaded, args.outDir, args.assetBaseUrl);
  }
};
var isDirectRun = process.argv[1]?.endsWith("index.js") || process.argv[1]?.endsWith("index.ts");
if (isDirectRun) {
  main(process.argv.slice(2)).catch((error) => {
    if (error instanceof CliUsageError || error instanceof DesignBundleValidationError) {
      console.error(error.message);
      process.exit(1);
    }
    throw error;
  });
}
export {
  loadDesignBundle,
  parseCliArgs
};
